

<?php
//including the database connection file
include_once("config.php");

if(isset($_POST['Submit'])) {	
	$name = mysqli_real_escape_string($mysqli, $_POST['name']);
	$mobile = mysqli_real_escape_string($mysqli, $_POST['mobile']);
	$email = mysqli_real_escape_string($mysqli, $_POST['email']);
	$address = mysqli_real_escape_string($mysqli, $_POST['address']);
	 
	 $gender = mysqli_real_escape_string($mysqli, $_POST['gender']);
	
		
	// checking empty fields
	if(empty($name) || empty($mobile) || empty($email)|| empty($address) || empty($gender)) {
				
		if(empty($name)) {
			echo "<font color='red'>Name field is empty.&nbsp;&nbsp;</font>";
		}
		
		if(empty($mobile)) {
			echo "<font color='red'>MOBILE field is empty.&nbsp;&nbsp;</font>";
		}
		
		if(empty($email)) {
			echo "<font color='red'>Email field is empty.&nbsp;&nbsp;</font>";
		}
		if(empty($address)) {
			echo "<font color='red'>Address field is empty.&nbsp;&nbsp;</font>";
		}
		
		if(empty($gender)) {
			echo "<font color='red'>Gender field is empty.&nbsp;&nbsp;</font>";
		}
		
		//link to the previous page
		
	} else { 
		// if all the fields are filled (not empty) 
			
		//insert data to database	
		$result = mysqli_query($mysqli, "INSERT INTO users1(name,mobile,email,address,gender) VALUES('$name','$mobile','$email','$address','$gender')");
		
		//display success message
		echo "<font color='green'>Data added successfully.";
		
	}
}
?>

<html>
<head>
	<title>USER REGISTER PAGE</title>
   <!--Made with love by Mutiullah Samim -->
   
	<!--Bootsrap 4 CDN-->
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    
    <!--Fontawesome CDN-->
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css" integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous">

	<!--Custom styles-->
	<link rel="stylesheet" type="text/css" href="style.css">
	<style>
	input[type='radio'] {
        width: 25px;
        height: 25px;
        border-radius: 15px;
        top: 4px;
       margin-left: 31px;
	   text-color:white;
          }
	</style>
</head>


<body background="bg.jpg">
<div class="container"><br><br>



	<a href="login.php"> <button type="button" class="btn btn-outline-primary waves-effect"><span class="glyphicon glyphicon-log-in"></span>Login</button></a>
<a href="logout.php"><button type="button" class="btn btn-outline-default waves-effect"> <i class="fa fa-power-off"></i>Logout</button></a>
<br><br>
  
 <a href="add.html"> <img src="1.jpg"  style="display: block;margin-left: auto;margin-right: auto;width: 25%; border: 2px solid red;border-radius: 25px;height:100px;"></a>

	<br><br>
	
	<div class="d-flex justify-content-center ">
		<div class="card">
			<div class="card-header">
				
				
			</div>
			<div class="card-body">
			
			

				<form method="post" action="" name="form1">
					<div class="input-group form-group">
						<div class="input-group-prepend">
							<span class="input-group-text"><i class="fas fa-user"></i></span>
						</div>
						<input type="text" class="form-control" name="name" placeholder="Username">
						
					</div>
					<div class="input-group form-group">
						<div class="input-group-prepend">
							<span class="input-group-text"><i class="fa fa-mobile" ></i></i></span>
						</div>
						<input type="text"  name="mobile" class="form-control" placeholder="mobile Number">
					</div>
					<div class="input-group form-group">
						<div class="input-group-prepend">
							<span class="input-group-text"><i class="fa fa-envelope" aria-hidden="true"></i></span>
						</div>
						<input type="text"  name="email" class="form-control" placeholder="email_id">
					</div>
					<div class="input-group form-group">
						<div class="input-group-prepend">
							<span class="input-group-text"><i class="fa fa-address-card" aria-hidden="true"></i></span>
						</div>
						<input type="text"  name="address" class="form-control" placeholder="Addrress">
					</div>
					<div class="input-group form-group">
						<div class="input-group-prepend">
							<span class="input-group-text"><i class="fa fa-users" aria-hidden="true"></i></span>
						</div>
						 <input type="radio" name="gender" value="male" checked ><span class=""style="color:white;" > Male</span>
                <input type="radio" name="gender" value="female"><span class=""style="color:white;">  Female</span>
					</div>
										<div class="form-group">
						<input type="submit"  name="Submit" value="Add" class="btn float-right login_btn">
					</div>
				</form>

			</div>
			
		</div>
	</div>
</div>

	
</body>



</html>

