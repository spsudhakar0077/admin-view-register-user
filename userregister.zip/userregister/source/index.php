
<?php
session_start();

//connect to database
include_once("config.php");


if (empty($_SESSION['username'])) {
    header('Location: login.php');
    exit;
}

?>
<?php
//including the database connection file
include_once("config.php");

//fetching data in descending order (lastest entry first)
//$result = mysql_query("SELECT * FROM users ORDER BY id DESC"); // mysql_query is deprecated
$result = mysqli_query($mysqli, "SELECT * FROM users1 ORDER BY id DESC"); // using mysqli_query instead
?>


<!DOCTYPE html>
<html lang="en">
<head>
  <title>DASHBOARD</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="style.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

  <style>
  table,td,th
	{
		border:2px solid red;
		
	}
	tr:nth-child(even){background-color:#636060;}


	table
	{
		border-collapse:collapse;
		width:100%;
	}
	td
	{
		height:60px;
		text-align:center;
	}
	tr
	{
		background-color: #636060;
		color:white;
	}
	th
	{
		
	
		color:white;
	}
th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align:center;
  background-color: black;
  color: white;
  height:60px;
}
  </style>
  
</head>

<body  background="bg.jpg">
 <br> <br>
<div class="container">
<a href="../add.html"><button type="button" class="btn btn-outline-default waves-effect"> <i class="fa fa-user" aria-hidden="true"></i>USER REGISTER</button></a>
      <a href="login.php"> <button type="button" class="btn btn-outline-primary waves-effect"><span class="glyphicon glyphicon-log-in"></span>Login</button></a>
<a href="logout.php"><button type="button" class="btn btn-outline-default waves-effect"> <i class="fa fa-power-off"></i>Logout</button></a>

     
    
  



<br>
<br>
<h1  style="color:white;text-align:center;">VIEW REGISTER USER</h1><br><br>
<div class="registerdata">
	<table width='100%'>

	<tr bgcolor='#CCCCCC'>
		<th>Name</th>
		<th>mobile No</th>
		<th>Email Id</th>
		<th>Address</th>
		<th>Gender</td>
		<th>Update User Details</th>
	</tr>
	<?php 
	//while($res = mysql_fetch_array($result)) { // mysql_fetch_array is deprecated, we need to use mysqli_fetch_array 
	while($res = mysqli_fetch_array($result)) { 		
		echo "<tr>";
		echo "<td>".$res['name']."</td>";
		echo "<td>".$res['mobile']."</td>";
		echo "<td>".$res['email']."</td>";	
		echo "<td>".$res['address']."</td>";
		echo "<td>".$res['gender']."</td>";
		echo "<td><a href=\"edit.php?id=$res[id]\">Edit</a> | <a href=\"delete.php?id=$res[id]\" onClick=\"return confirm('Are you sure you want to delete?')\">Delete</a></td>";		
	}
	?>
	</table>
</div>

</div>

</body>
</html>


