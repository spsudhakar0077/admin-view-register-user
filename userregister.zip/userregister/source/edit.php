
<?php
session_start();

//connect to database
include_once("config.php");


if (empty($_SESSION['username'])) {
    header('Location: login.php');
    exit;
}

?>


<?php
// including the database connection file


if(isset($_POST['update']))
{	

	$id = mysqli_real_escape_string($mysqli, $_POST['id']);
	
	$name = mysqli_real_escape_string($mysqli, $_POST['name']);
	$mobile = mysqli_real_escape_string($mysqli, $_POST['mobile']);
	$email = mysqli_real_escape_string($mysqli, $_POST['email']);
	$address = mysqli_real_escape_string($mysqli, $_POST['address']);
	$gender = mysqli_real_escape_string($mysqli, $_POST['gender']);
	
	
	// checking empty fields
	if(empty($name) || empty($mobile) || empty($email)|| empty($address) || empty($gender)) {	
			
		if(empty($name)) {
			echo "<font color='red'>Name field is empty.&nbsp;&nbsp;</font>";
		}
		
		if(empty($mobile)) {
			echo "<font color='red'>MOBILE field is empty.&nbsp;&nbsp;</font>";
		}
		
		if(empty($email)) {
			echo "<font color='red'>Email field is empty.&nbsp;&nbsp;</font>";
		}
		if(empty($address)) {
			echo "<font color='red'>Address field is empty.&nbsp;&nbsp;</font>";
		}
		
		if(empty($gender)) {
			echo "<font color='red'>Gender field is empty.&nbsp;&nbsp;</font>";
		}		
	} else {	
		//updating the table
		$result = mysqli_query($mysqli, "UPDATE users1 SET name='$name',mobile='$mobile',email='$email',address='$address',gender='$gender' WHERE id=$id");
		
		//redirectig to the display page. In our case, it is index.php
		header("Location: index.php");
	}
}
?>
<?php
//getting id from url
$id = $_GET['id'];

//selecting data associated with this particular id
$result = mysqli_query($mysqli, "SELECT * FROM users1 WHERE id=$id");

while($res = mysqli_fetch_array($result))
{
	$name = $res['name'];
	$mobile = $res['mobile'];
	$email = $res['email'];
	$address = $res['address'];
	$gender = $res['gender'];

}
?>
<html>
<head>
	<title>USER PAGE EDIT</title>
   <!--Made with love by Mutiullah Samim -->
   
	<!--Bootsrap 4 CDN-->
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    
    <!--Fontawesome CDN-->
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css" integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous">

	<!--Custom styles-->
	<link rel="stylesheet" type="text/css" href="style.css">
	<style>
	input[type='radio'] {
        width: 25px;
        height: 25px;
        border-radius: 15px;
        top: 4px;
       margin-left: 31px;
	   text-color:white;
          }
	</style>
</head>

<body background="bg.jpg"><br>
<h1  style="color:white;text-align:center;">EDIT USER DETAILS</h1><br>
<div claa="container"style="margin-top:-10%">
	
	
	<div class="d-flex justify-content-center h-100">
		<div class="card">
			<div class="card-header">
				
				
			</div>
			<div class="card-body">
	
	<form name="form1" method="post" action="edit.php">
					<div class="input-group form-group">
						<div class="input-group-prepend">
							<span class="input-group-text"><i class="fas fa-user"></i></span>
						</div>
						<input type="text" class="form-control" name="name" value="<?php echo $name;?>">
						
					</div>
					<div class="input-group form-group">
						<div class="input-group-prepend">
							<span class="input-group-text"><i class="fa fa-mobile"></i></span>
						</div>
						<input type="text"  name="mobile" class="form-control"  value="<?php echo $mobile;?>" >
					</div>
					<div class="input-group form-group">
						<div class="input-group-prepend">
							<span class="input-group-text"><i class="fa fa-envelope" aria-hidden="true"></i></span>
						</div>
						<input type="text"  name="email" class="form-control"value="<?php echo $email;?>"">
					</div>
					<div class="input-group form-group">
						<div class="input-group-prepend">
							<span class="input-group-text"><i class="fa fa-address-card" aria-hidden="true"></i></span>
						</div>
						<input type="text"  name="address" class="form-control" value="<?php echo $address;?>">
					</div>
					<div class="input-group form-group">
						<div class="input-group-prepend">
							<span class="input-group-text"><i class="fa fa-users" aria-hidden="true"></i></span>
						</div>
						 <input type="radio" name="gender" value="male"<?php echo ($gender=='male')?'checked':'' ?>size="17"><span class=""style="color:white;"> Male</span>
                <input type="radio" name="gender"  value="female" <?php echo ($gender=='female')?'checked':'' ?>size="17"><span class=""style="color:white;">  Female</span>
					</div>
										<div class="form-group">
				         <input type="hidden" name="id" value=<?php echo $_GET['id'];?>>
						<input type="submit"  name="update" value="UPDATE" class="btn float-right login_btn">
					</div>
				</form>
</div>
</div>
</div>
	</div>
</body>
</html>
